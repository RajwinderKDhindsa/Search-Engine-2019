package websearchengine.models;

public class TSTNode {
	public int fileIdx;
	public int line;
	
	public TSTNode(int fileIdx, int line) {
		this.fileIdx = fileIdx;
		this.line = line;
	}
}
