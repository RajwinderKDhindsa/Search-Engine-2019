package websearchengine.websortservice;

public interface quickSort {

}
