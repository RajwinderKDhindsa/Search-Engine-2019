package websearchengine.searchservices;

public interface TSTStringTokenizer {

	public String getFileName(int fileIdx);
	public void readFile();

}
