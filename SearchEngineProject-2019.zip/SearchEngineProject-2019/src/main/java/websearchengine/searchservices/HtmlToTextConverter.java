package websearchengine.searchservices;

public interface HtmlToTextConverter {
	
	public void readHtmlFiles();
	public void writeToText(String filename);

}
